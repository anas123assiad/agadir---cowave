from flask import Flask, render_template
from donnees import episodes

app = Flask(__name__)

@app.context_processor
def injecter_episodes():
    return {"episodes": episodes}

@app.route("/")
def accueil():
    return render_template("accueil.html", episodes=episodes)

@app.route("/films")
def films():
    return render_template("films.html", episodes=episodes)

@app.route("/episode/<int:numero>")
def episode(numero):
    ep = episodes[numero]
    return render_template("episode.html", ep=ep)

@app.route("/administration")
def administration():
    return render_template("administration.html")

@app.route("/a-propos")
def a_propos():
    return render_template("a-propos.html")

@app.route("/charte")
def charte():
    return render_template("charte.html")

@app.route("/corrections")
def corrections():
    return render_template("corrections.html")

@app.route("/audio")
def audio():
    return render_template("bientot.html", nom="Audio", description="Des conversations audio avec des diplômés de l'ENCG Agadir : leurs parcours, leurs métiers, leurs conseils.")

@app.route("/guides")
def guides():
    return render_template("bientot.html", nom="Guides", description="Des guides courts et pratiques pour les étudiants : méthodes de travail, stages, projets.")

@app.route("/outils")
def outils():
    return render_template("bientot.html", nom="Outils", description="Des outils simples pour les étudiants en économie et gestion : modèles, calculateurs, check-lists.")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
