episodes = [
    {
        "numero": 0,
        "titre": "Prologue — Une décision peut changer le monde",
        "scenes": 9,
        "statut": "brouillon",
        "resume": "Le 15 août 1971, Nixon ferme le guichet de l'or : en une allocution, le système monétaire mondial bascule. Le film pose sa question : qui décide de l'argent du monde ?",
        "transcription": """Le 15 août 1971, le président américain Richard Nixon apparaît à la télévision. En quelques minutes d'allocution, il annonce une mesure qui va bouleverser la planète : le dollar ne sera plus convertible en or.

Depuis 1944, les banques centrales étrangères pouvaient échanger leurs dollars contre de l'or, à un prix fixe de trente-cinq dollars l'once. Ce soir-là, Nixon ferme ce guichet. Le lien entre la monnaie mondiale et le métal précieux est rompu.

Aucune guerre n'est déclarée, aucun traité n'est signé. Pourtant, une seule annonce suffit pour que le système monétaire international bascule dans une ère entièrement nouvelle : la nôtre.

Car l'argent n'est pas seulement un outil d'échange. Au fil du vingtième siècle, il est devenu un instrument de pouvoir : celui qui contrôle la monnaie contrôle les échanges, les dettes, et parfois le destin des nations.

Ce documentaire raconte comment le dollar est devenu le centre de la finance mondiale, comment de grandes décisions l'ont renforcé, puis transformé en arme géopolitique au service des plus puissants.

Mais il raconte aussi la riposte. Partout dans le monde émergent des modèles alternatifs : financer sans intérêt, prêter aux exclus, se passer des banques, ou créer des monnaies qu'aucun État ne contrôle directement.

Pendant que quelques capitales décident de la monnaie du monde, des milliards de personnes vivent à l'écart de la finance : sans compte, sans crédit, sans protection. Ce contraste est le point de départ de notre histoire.

Voici l'idée qui guidera ce film : le pouvoir monétaire se concentre quand l'argent est centralisé, et il est contesté dès qu'il devient une arme. Chaque partie va tester cette idée, avec ses preuves et ses limites.

Une question traverse ce récit : qui décide de l'argent du monde ? Et surtout, qui commence aujourd'hui à contester ce pouvoir, et avec quelles armes financières nouvelles ? La réponse se construit sous nos yeux.""",
        "sources": [
            "Richard Nixon, allocution télévisée du 15 août 1971 : suspension de la convertibilité du dollar en or",
            "Accords de Bretton Woods, 1944 : convertibilité du dollar à 35 dollars l'once d'or",
        ],
        "questions": [
            "Une décision politique peut-elle changer le système monétaire mondial du jour au lendemain ?",
            "Que perd le monde lorsque la monnaie n'est plus adossée à un actif réel ?",
            "Le pouvoir monétaire est-il forcément concentré entre quelques mains ?",
        ],
    },
    {
        "numero": 1,
        "titre": "Comment l'argent est devenu un pouvoir",
        "scenes": 16,
        "statut": "brouillon",
        "resume": "De Bretton Woods au pétrodollar : comment le dollar est devenu l'infrastructure de la finance mondiale — et le privilège de celui qui l'émet.",
        "transcription": """Pour comprendre le pouvoir du dollar, il faut revenir à juillet 1944, à Bretton Woods, dans le New Hampshire. Les délégués de quarante-quatre nations alliées y dessinent l'ordre monétaire qui régira le monde de l'après-guerre.

L'économiste britannique John Maynard Keynes propose une monnaie mondiale, le « Bancor », gérée par une institution internationale. Mais les États-Unis, créanciers du monde, refusent : c'est le dollar, adossé à l'or, qui s'impose.

La leçon de Bretton Woods est durable : les règles de l'argent ne sont pas neutres. Elles sont écrites par les vainqueurs et reflètent le rapport de force du moment où elles naissent.

Le dollar devient la monnaie de référence. Les banques centrales le détiennent en réserve, les matières premières se négocient dans cette devise, et les États-Unis deviennent le banquier central du système tout entier.

Deux institutions naissent de cette conférence : le Fonds monétaire international, chargé de veiller à la stabilité des monnaies, et la Banque mondiale, chargée de financer la reconstruction, puis le développement.

Ces institutions sont les gardiennes du système. Elles prêtent aux États en difficulté, mais contre des conditions strictes : budgets resserrés, réformes imposées. Pour beaucoup de pays, l'aide ressemble parfois à une perte de souveraineté.

En 1973, le choc pétrolier fait flamber le prix du baril. Les pays producteurs s'enrichissent brutalement, et une question stratégique se pose : dans quelle monnaie le pétrole du monde entier sera-t-il payé ?

À partir de 1974, une entente discrète est conclue entre Washington et Riyad : le pétrole saoudien sera facturé en dollars, et les excédents du royaume seront placés en bons du Trésor américains. Les historiens en débattent encore les détails.

Le mécanisme est redoutable : pour acheter du pétrole, chaque pays doit d'abord se procurer des dollars. La demande mondiale pour la monnaie américaine devient structurelle, presque indépendante de la santé réelle de l'économie des États-Unis.

Le dollar n'est plus seulement une monnaie nationale : c'est une infrastructure mondiale. Commercer, emprunter, épargner, tout passe par lui. Et celui qui l'émet détient un privilège qu'aucun autre pays ne possède.

On attribue à Valéry Giscard d'Estaing, alors ministre français des Finances, l'expression « privilège exorbitant ». Les États-Unis financent leurs déficits en émettant la monnaie que le monde réclame, et leurs dettes trouvent toujours preneur.

Autour de ce centre gravitent les grandes places financières : New York, Londres, et quelques autres capitales de la finance mondiale. C'est là que se décident les taux, les notations, et le sort de nombreux emprunteurs.

Les grands fonds d'investissement y déplacent des capitaux colossaux, parfois supérieurs aux budgets de certains États. En quelques clics, ils peuvent financer un pays, ou le plonger brutalement dans une crise de confiance.

Les banques centrales complètent ce dispositif : elles fixent les taux d'intérêt qui commandent le prix de l'argent partout ailleurs. Quand la Réserve fédérale américaine bouge, les économies du monde entier en ressentent les effets.

Ce pouvoir n'est pas qu'économique. Il permet de récompenser des alliés, de financer des efforts de guerre, ou de priver un adversaire désigné d'accès aux circuits financiers qui font vivre son commerce extérieur.

À la fin du vingtième siècle, la finance est donc un système mondial hiérarchisé, avec un centre, des gardiens et des règles. Mais ce système, en apparence solide, va connaître ses plus grandes secousses.""",
        "sources": [
            "Conférence de Bretton Woods, juillet 1944 : naissance du FMI et de la Banque mondiale",
            "Entente États-Unis – Arabie saoudite, 1974 : facturation du pétrole en dollars (le « pétrodollar »)",
            "Valéry Giscard d'Estaing, ministre français des Finances : l'expression « privilège exorbitant »",
        ],
        "questions": [
            "Les règles du système monétaire sont-elles neutres, ou écrites par les plus forts ?",
            "Le pétrodollar explique-t-il à lui seul la puissance du dollar ?",
            "Que se passerait-il si le pétrole se payait dans une autre monnaie ?",
        ],
    },
    {
        "numero": 2,
        "titre": "Les grandes décisions et les guerres de l'argent",
        "scenes": 20,
        "statut": "brouillon",
        "resume": "Crises, sanctions, réseaux : quand la finance devient une arme, le monde cherche des issues de secours.",
        "transcription": """Le 15 août 1971 n'était que le premier acte. En détachant le dollar de l'or, Nixon ouvre l'ère de la monnaie fiduciaire : sa valeur ne repose plus que sur la confiance et sur la loi.

Cette confiance va être mise à l'épreuve en 2008. La crise des crédits immobiliers américains, les fameux subprimes, révèle que les grandes banques ont empilé des risques qu'elles ne comprenaient plus elles-mêmes.

En septembre 2008, la banque d'investissement Lehman Brothers s'effondre. La panique se propage en quelques jours à toute la planète : les marchés s'arrêtent, le crédit se fige, et des millions d'emplois disparaissent dans la récession.

Pour éviter l'effondrement, les États sauvent les banques avec l'argent public, et les banques centrales créent de la monnaie à une échelle inédite. Le message reçu par les citoyens est brutal : les banques gagnent, les peuples paient.

La crise de 2008 laisse une trace profonde : la conviction que le système protège d'abord ceux qui le dirigent. Dans ce climat de défiance, un auteur mystérieux publie, fin octobre 2008, le texte fondateur d'une invention appelée Bitcoin.

Mais le pouvoir financier ne s'exerce pas seulement par les crises. Il s'exerce aussi par les réseaux. Le plus stratégique s'appelle SWIFT : c'est par lui que les banques du monde entier s'échangent leurs instructions de paiement.

Détail méconnu : SWIFT ne déplace aucun argent. C'est une messagerie sécurisée entre banques, organisée en coopérative installée en Belgique. Pourtant, être exclu de ce réseau revient à être presque coupé du commerce mondial.

En 2019, deux chercheurs américains, Henry Farrell et Abraham Newman, donnent un nom à ce phénomène : l'« interdépendance instrumentalisée ». Quand le monde dépend de quelques réseaux, ceux qui les contrôlent détiennent une arme sans armée.

Dès 2012, des banques iraniennes sont déconnectées de SWIFT. D'autres pays voient ensuite leurs avoirs bloqués et leurs exportations freinées. La finance devient un instrument de guerre qui ne nécessite aucune invasion militaire.

En 2022, après l'invasion de l'Ukraine, environ trois cents milliards de dollars de réserves de la banque centrale de Russie sont immobilisés à l'étranger. Une mesure sans précédent, à cette échelle, pour une grande économie.

La leçon est retenue partout : détenir des réserves en dollars ou en euros n'est plus une garantie absolue. Si l'accès à ses propres économies peut être suspendu par décision politique, la confiance elle-même devient conditionnelle.

La riposte s'organise d'abord au sein des BRICS, ce groupe de puissances émergentes qui contestent l'ordre financier hérité de l'après-guerre. Leur revendication est simple : commercer davantage dans leurs propres monnaies nationales.

Concrètement, des accords permettent désormais à certains pays de payer leur énergie ou leurs importations sans passer par le dollar. Chaque transaction de ce type, même modeste, rogne un peu le monopole de la monnaie américaine.

Les banques centrales renforcent aussi leurs réserves d'or, valeur refuge qui ne dépend d'aucun État émetteur. De 2022 à 2024, elles en ont acheté plus de mille tonnes par an. L'or, chassé du système en 1971, revient au cœur des stratégies monétaires.

Plusieurs banques centrales testent aussi leur propre monnaie numérique. La Chine déploie l'e-yuan, et le projet mBridge permet, à titre expérimental, à quelques banques centrales d'Asie et du Golfe de régler leurs échanges sans la chaîne classique des banques correspondantes.

Face à cette contestation, les gardiens du système défendent leur modèle : la stabilité du dollar, la profondeur des marchés américains et la sécurité juridique qu'offrent leurs institutions aux investisseurs du monde entier.

Les chiffres nuancent d'ailleurs le récit. Le dollar représente encore près de six dollars sur dix des réserves de change mondiales, et figure dans près de neuf opérations de change sur dix. Le contester est une chose ; le remplacer en est une autre.

Pourquoi une telle résistance ? Aucune autre monnaie ne réunit à la fois des marchés aussi profonds, une justice indépendante et la libre circulation des capitaux. Les alternatives progressent, mais le dollar garde, pour l'instant, une longueur d'avance.

Le mot « dédollarisation » résume ce bras de fer : il ne s'agit pas d'un effondrement brutal, mais d'une érosion lente. Le monde ne quitte pas le dollar ; il apprend progressivement à s'en passer en partie.

Les grandes décisions ont donc produit leur propre contestation. Plus le pouvoir financier est utilisé comme une arme, plus ses cibles cherchent des issues de secours. Et ces issues existent déjà, dans les marges du système.""",
        "sources": [
            "Henry Farrell et Abraham Newman, « Weaponized Interdependence », International Security, 2019",
            "FMI, base COFER : parts des monnaies dans les réserves de change mondiales",
            "Banque des règlements internationaux, enquête triennale 2025 sur les marchés de change",
            "World Gold Council, Gold Demand Trends : achats d'or des banques centrales",
        ],
        "questions": [
            "Peut-on exclure un pays du système financier sans tirer un coup de feu ?",
            "La dédollarisation est-elle un effondrement, ou une érosion lente ?",
            "Pourquoi l'or, écarté en 1971, revient-il au centre des stratégies des banques centrales ?",
        ],
    },
    {
        "numero": 3,
        "titre": "Les fissures du système",
        "scenes": 12,
        "statut": "brouillon",
        "resume": "Exclusion, dette en devises, climat, confiance : les quatre fissures qui ont fait naître les alternatives.",
        "transcription": """Pendant que la haute finance décide du sort des États, une autre réalité persiste : plus d'un milliard d'adultes dans le monde vivent sans compte bancaire, sans épargne formelle, et sans accès au crédit.

Pour ces populations, la banque est un monde lointain : agences absentes des campagnes, documents exigés impossibles à fournir, revenus trop modestes pour intéresser les guichets. L'exclusion financière est silencieuse, mais elle enferme des vies entières.

Deuxième fissure : la dette. De nombreux pays pauvres empruntent dans des monnaies qui ne sont pas les leurs. Les économistes parlent de « péché originel » : quand le dollar monte, leurs remboursements explosent, et la santé ou l'éducation passent après les créanciers.

Cette dépendance monétaire est une forme de pouvoir rarement discutée : un pays peut être politiquement indépendant, tout en voyant ses choix budgétaires dictés par les marchés de change et par des taux décidés loin de chez lui.

Troisième fissure : le climat. Le système financier excelle à financer le court terme et les rendements immédiats. Mais la transition écologique exige des investissements patients, dont les fruits ne viendront que dans des décennies.

Pendant des années, les capitaux ont continué d'irriguer massivement les énergies fossiles, tandis que les projets verts peinaient à trouver des financements. L'argent allait là où le rendement était rapide, pas là où l'avenir se jouait.

Quatrième fissure : la confiance. Après 2008, beaucoup de citoyens ont cessé de croire que les règles du jeu étaient les mêmes pour tous. Quand les banques sont sauvées et les ménages expulsés, la légitimité du système vacille.

Cette méfiance n'est pas qu'un sentiment : elle devient un moteur économique. Des épargnants cherchent des placements qu'ils comprennent, des entrepreneurs des financements sans intermédiaires, des communautés des circuits où la confiance circule autrement.

Il faut le souligner : la finance alternative ne naît pas d'un caprice idéologique. Elle naît de besoins concrets que le système classique n'a pas satisfaits : être inclus, être financé, être respecté dans ses convictions.

Chaque fissure du système dominant ouvre donc un espace. Là où la banque refuse un prêt, un fonds de microcrédit peut l'accorder. Là où le marché ignore un projet, une foule de particuliers peut le financer directement.

Certaines de ces réponses sont anciennes, presque ancestrales : l'entraide, la tontine, le prêt entre proches. D'autres sont nées avec Internet et la téléphonie mobile. Toutes partagent un point de départ : la confiance plutôt que la bureaucratie.

Ces alternatives, longtemps jugées marginales, commencent à peser : elles drainent des capitaux, inspirent des lois, attirent des États. Ce ne sont plus des expériences isolées, mais de nouvelles forces dans l'équilibre financier mondial.""",
        "sources": [
            "Banque mondiale, Global Findex 2025 : adultes sans compte bancaire dans le monde",
            "Barry Eichengreen et Ricardo Hausmann : le « péché originel » de la dette en devises étrangères",
        ],
        "questions": [
            "Pourquoi l'exclusion financière persiste-t-elle malgré la technologie ?",
            "Un pays endetté en dollars est-il vraiment libre de ses choix budgétaires ?",
            "La finance alternative naît-elle d'une idéologie, ou de besoins concrets ?",
        ],
    },
    {
        "numero": 4,
        "titre": "Les alternatives, de nouvelles forces",
        "scenes": 24,
        "statut": "brouillon",
        "resume": "Finance islamique, microfinance, circuits collectifs, finance durable, argent mobile et crypto : cinq forces qui contestent le modèle dominant.",
        "transcription": """Première force alternative : la finance islamique. Son principe fondateur est clair : l'intérêt est interdit, car l'argent ne doit pas produire de l'argent par lui-même. Tout financement doit s'adosser à un actif ou à un projet réel.

À la place du prêt classique, elle propose des contrats de partage : la banque achète le bien et le revend avec une marge connue, ou devient associée du projet, partageant ainsi les profits comme les pertes éventuelles.

Ce modèle n'est pas qu'une question de foi. Avec des actifs qui dépassent les trois mille milliards de dollars dans le monde, la finance islamique est devenue un circuit parallèle puissant, alimenté par les capitaux du Golfe et courtisé par les grandes places.

Ses détracteurs soulignent pourtant que certains produits ressemblent à des prêts classiques habillés autrement. Le défi de la finance islamique est de prouver qu'elle change la logique du risque partagé, et pas seulement le vocabulaire des contrats.

Deuxième force : la microfinance. Son pari, formulé au Bangladesh par Muhammad Yunus, prix Nobel de la paix en 2006, est renversant : prêter de très petites sommes à ceux que les banques jugent insolvables, en misant sur leur parole et leur travail.

La Grameen Bank prête d'abord aux femmes des villages : selon la banque elle-même, environ quatre-vingt-dix-huit pour cent de ses emprunteuses sont des femmes, un choix qu'elle justifie par leur sérieux dans le remboursement et l'effet sur toute la famille.

Le microcrédit a essaimé sur tous les continents. Le Maroc compte parmi les pays où il s'est profondément enraciné, avec des associations spécialisées comme Al Amana, qui financent les petits commerces et l'artisanat des quartiers populaires.

Mais le microcrédit n'est pas une solution miracle. En 2010, une crise de surendettement frappe l'État indien d'Andhra Pradesh et rappelle qu'un crédit mal encadré peut piéger au lieu de libérer. Régulation et protection de l'emprunteur sont décisives.

Troisième force : le collectif. Le financement participatif, ou crowdfunding, permet à une foule de particuliers de financer directement un projet, par le don, par le prêt, ou en prenant une petite part de son capital.

Ce modèle ne doit rien à la technologie : il prolonge des pratiques anciennes. La tontine, que le Maroc connaît sous le nom de daret, fait circuler l'épargne d'un groupe où chacun reçoit la cagnotte à son tour.

Plus ancien encore, le hawala fonctionne depuis des siècles sur la seule confiance : l'argent remis à un correspondant dans une ville est versé par un autre ailleurs, sans déplacement physique des fonds. Sa discrétion pose aujourd'hui un défi de traçabilité.

Les coopératives complètent ce paysage : détenues par leurs membres, elles décident collectivement de l'usage de l'épargne commune. Pas d'actionnaires lointains ; l'institution appartient à ceux qui l'utilisent chaque jour pour travailler.

Ces circuits ont toutefois leurs limites : beaucoup de campagnes de financement participatif n'atteignent jamais leur objectif, et l'investisseur particulier peut perdre sa mise sans véritable recours. La confiance doit s'accompagner de règles.

Quatrième force : la finance durable. Elle propose de juger un investissement selon trois critères, dits ESG : l'environnement, le social et la gouvernance. L'argent ne demanderait plus seulement combien il rapporte, mais comment il le rapporte.

En 2008, la Banque mondiale émet ses premières obligations vertes, à la demande d'investisseurs suédois, un an après un précurseur : la Banque européenne d'investissement. L'idée naît d'une question simple : que finance exactement notre argent pour le climat ?

Depuis, les obligations vertes et les fonds durables drainent des capitaux croissants vers les énergies renouvelables, l'eau, les transports propres. La finance découvre qu'elle peut être un levier de transition, et pas seulement un frein.

Mais cette force a son angle mort : le greenwashing. Certaines entreprises se peignent en vert sans changer leurs pratiques. La finance durable devra prouver, chiffres et contrôles à l'appui, qu'elle transforme vraiment les comportements.

Cinquième force : la technologie entre les mains des exclus. En 2007, au Kenya, naît M-Pesa : un simple téléphone portable devient un compte, un guichet, un moyen de paiement pour des millions de personnes sans banque.

La leçon de M-Pesa est historique : la révolution de l'argent mobile a commencé en Afrique, dès 2007, avant même le Bitcoin. Elle n'a eu besoin ni des banques traditionnelles, ni d'une cryptomonnaie sophistiquée.

En janvier 2009, Satoshi Nakamoto crée le premier bloc du Bitcoin. Il y grave le titre du Times : « Chancellor on brink of second bailout for banks », un ministre au bord d'un second sauvetage des banques.

Ce message n'est pas un hasard : le Bitcoin naît comme une protestation. Contre les sauvetages bancaires et l'argent créé par décret, ses créateurs imaginent une monnaie qu'aucun État ni aucune banque ne peut fabriquer à volonté.

De cette révolte naît tout un écosystème : les cryptomonnaies, puis la finance décentralisée, où des contrats automatiques exécutent prêts et échanges sans intermédiaire humain. La promesse est immense : une finance ouverte, programmable, accessible à tous.

Paradoxe : parmi les cryptomonnaies les plus utilisées, les stablecoins sont indexés sur le dollar. Leurs émetteurs placent leurs réserves en bons du Trésor américain, et Washington a choisi de les encadrer par une loi en 2025. La révolte pourrait finir par renforcer le dollar.

Cette force a un prix : une volatilité extrême, des fraudes, des plateformes qui s'effondrent sans recours pour les épargnants. Entre la liberté promise et le risque réel, la crypto reste le territoire le plus disputé.""",
        "sources": [
            "IFSB (Islamic Financial Services Board) : actifs mondiaux de la finance islamique",
            "Muhammad Yunus, Vers un monde sans pauvreté ; rapports de la Grameen Bank",
            "Banque mondiale, premières obligations vertes (2008) ; Banque européenne d'investissement, Climate Awareness Bond (2007)",
            "Safaricom, lancement de M-Pesa au Kenya (2007)",
            "Bloc genesis du Bitcoin, 3 janvier 2009 : titre du Times gravé par Satoshi Nakamoto",
        ],
        "questions": [
            "La finance islamique change-t-elle la logique du risque, ou seulement le vocabulaire des contrats ?",
            "Le microcrédit libère-t-il toujours, ou peut-il aussi piéger ?",
            "Les stablecoins, indexés sur le dollar, renforcent-ils le système qu'ils prétendent contourner ?",
        ],
    },
    {
        "numero": 5,
        "titre": "Le Maroc dans cette bataille",
        "scenes": 13,
        "statut": "brouillon",
        "resume": "Banques participatives, loi sur le financement collaboratif, micro-crédit, daret, transferts des MRE : le Maroc adopte les alternatives pas à pas, sous supervision.",
        "transcription": """Dans cette bataille mondiale, où se place le Maroc ? Le royaume a fait un choix mesuré : ouvrir son système financier aux modèles alternatifs, mais sous le contrôle strict de sa banque centrale, Bank Al-Maghrib.

Depuis 2017, des banques participatives, comme Umnia Bank ou Bank Assafa, proposent au Maroc des financements conformes aux principes de la finance islamique : pas d'intérêt, des contrats adossés à des biens réels, sous la supervision de Bank Al-Maghrib et avec un avis de conformité religieuse.

Le financement participatif a aussi reçu son cadre légal : la loi 15-18 sur le financement collaboratif, promulguée en 2021, organise le métier des plateformes qui relient porteurs de projets et public prêt à les soutenir.

Le micro-crédit, lui, irrigue depuis longtemps les souks et les quartiers : de petites sommes prêtées aux commerçants et aux artisans que les banques classiques n'auraient jamais reçus dans leurs agences des grandes avenues.

Et la daret continue de tourner, de famille en famille, de quartier en quartier : chacun cotise, chacun reçoit la cagnotte à son tour. Sans contrat compliqué, sans intérêt, la solidarité marocaine fait office d'institution financière vivante.

Autre circuit essentiel : les Marocains du monde envoient chaque année plus de cent milliards de dirhams au pays. C'est l'une des premières sources de devises du royaume, et un terrain où banques, opérateurs de transfert et applications se disputent chaque dirham.

Depuis 2019, le Maroc suit une stratégie nationale d'inclusion financière. Porte-monnaie mobiles, paiement par QR code, services de proximité : l'objectif est de rapprocher de la finance ceux qui en étaient éloignés.

Pour les jeunes porteurs de projet, le programme Intelaka, lancé en 2020, associe crédits bancaires à taux préférentiels et garanties publiques. Preuve que l'inclusion financière devient aussi une politique d'État.

Les cryptomonnaies illustrent cette prudence. Interdites en 2017 par l'Office des changes, elles sont pourtant utilisées par de nombreux Marocains, et des travaux ont été engagés pour leur donner un cadre légal. Le défi est de protéger les épargnants sans fermer la porte à l'innovation.

Sur le terrain de la finance verte, le Maroc possède une vitrine mondiale : le complexe solaire Noor, près de Ouarzazate, l'un des plus grands au monde, financé par des bailleurs et des banques de développement internationaux, attirés par un projet d'avenir.

Géographiquement, le Maroc se tient entre deux mondes : lié à l'Europe par ses échanges, tourné vers l'Afrique par ses banques. Casablanca Finance City, créée en 2010, ambitionne d'en faire la porte d'entrée financière du continent.

Les défis restent réels : une part importante des paiements se fait encore en espèces, l'économie informelle demeure large, et l'éducation financière reste à construire. Les alternatives ne servent que si les citoyens les comprennent et les utilisent.

Le Maroc ne conteste pas le système mondial ; il négocie sa place en son sein. Il adopte les alternatives pas à pas, en les encadrant, convaincu que la finance de demain se construira aussi sur ses rives.""",
        "sources": [
            "Bank Al-Maghrib : banques participatives ; stratégie nationale d'inclusion financière (depuis 2019)",
            "Loi 15-18 relative au financement collaboratif, Dahir n° 1-21-24 du 22 février 2021, Bulletin Officiel n° 6967",
            "Office des changes : transferts des Marocains résidant à l'étranger ; communiqué de 2017 sur les cryptomonnaies",
        ],
        "questions": [
            "Le Maroc conteste-t-il le système mondial, ou négocie-t-il sa place en son sein ?",
            "La daret est-elle une institution financière comme les autres ?",
            "Comment encadrer les cryptomonnaies sans fermer la porte à l'innovation ?",
        ],
    },
    {
        "numero": 6,
        "titre": "Conclusion — Qui décidera demain ?",
        "scenes": 8,
        "statut": "brouillon",
        "resume": "Le pouvoir de l'argent ne disparaît pas : il change de mains. Qui décidera demain — et selon quelles règles ?",
        "transcription": """Alors, qui décidera de l'argent demain ? Probablement pas un seul centre, comme à Bretton Woods. Le monde financier qui s'annonce est multipolaire : plusieurs monnaies, plusieurs modèles, plusieurs puissances se partagent l'influence et les capitaux.

Dans ce paysage, la finance alternative n'est plus une marge pittoresque. Elle est devenue un rapport de force en construction : des États l'adoptent, des lois l'encadrent, des capitaux considérables commencent à circuler dans ses circuits propres.

Son potentiel est double : inclure celles et ceux que la finance classique a laissées au bord de la route, et réconcilier l'argent avec des valeurs : la confiance, le réel, la patience, la responsabilité envers la planète.

Mais ce potentiel n'est pas un destin assuré. Sans règles claires, les alternatives peuvent reproduire les abus du système qu'elles contestent : surendettement des plus fragiles, spéculation déguisée, promesses vertes sans lendemain.

L'enjeu des prochaines années sera donc institutionnel : réguler sans étouffer, protéger sans interdire, laisser l'innovation respirer tout en empêchant les nouvelles finances de devenir, à leur tour, des machines à exclure les plus faibles.

Pour nous, étudiants en commerce et en gestion, ces questions sont concrètes. Demain, nous choisirons des banques, des devises, des outils de paiement, et nous financerons des entreprises. Comprendre l'argent, c'est déjà commencer à décider.

Une chose est certaine : la question de 1971, celle du pouvoir de créer et de contrôler l'argent, n'a jamais été aussi ouverte. Elle se discute dans les banques centrales, les parlements, et jusque dans les téléphones portables.

Le pouvoir de l'argent ne disparaît pas : il change de mains. À chaque époque, de nouvelles mains s'en saisissent. La nôtre est en train de décider à qui appartiendra la finance de demain, et selon quelles règles.""",
        "sources": [
            "Synthèse du documentaire : voir les sources des parties 1 à 5",
            "Barry Eichengreen, Exorbitant Privilege (2011) : le privilège du dollar et ses limites",
        ],
        "questions": [
            "Un monde financier multipolaire sera-t-il plus juste, ou seulement plus fragmenté ?",
            "Quelles règles faut-il imposer aux alternatives pour qu'elles n'excluent pas à leur tour ?",
            "En tant qu'étudiants en gestion, quel rôle jouerons-nous dans la finance de demain ?",
        ],
    },
]
